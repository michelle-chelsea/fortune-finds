import { handler } from './api.ts';
import { runJobs } from './jobs.ts';
export default {async fetch(request:Request,env:any){const result=await handler(request,env);if(result)return result;if(env.ASSETS){const response=await env.ASSETS.fetch(request);if(response.status!==404)return response;return env.ASSETS.fetch(new Request(new URL('/index.html',request.url),request));}return new Response('Static assets are not connected.',{status:503});},async scheduled(_event:any,env:any,ctx:any){ctx.waitUntil(runJobs(env));}};

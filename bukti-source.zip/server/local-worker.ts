import { existsSync } from 'node:fs';
import { localDatabase } from './local-db.ts';
import { runJobs } from './jobs.ts';
if(existsSync('.env.local'))process.loadEnvFile('.env.local');
const env={...process.env,DB:localDatabase()};
const tick=async()=>{const result=await runJobs(env);console.log(new Date().toISOString(),JSON.stringify(result));};
await tick();setInterval(tick,60000);

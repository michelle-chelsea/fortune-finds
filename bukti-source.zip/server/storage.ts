export interface Statement { bind(...args: any[]): Statement; first<T = any>(): Promise<T | null>; all<T = any>(): Promise<{results:T[]}>; run(): Promise<any> }
export interface Database { prepare(sql:string):Statement; batch(statements:Statement[]):Promise<any[]> }
export type RecordData = {id:string; [key:string]:any};
export class Store {
  db: Database;
  constructor(db: Database) { this.db=db; }
  async list(kind:string):Promise<RecordData[]> { const r=await this.db.prepare('SELECT data FROM records WHERE kind=? ORDER BY updated DESC').bind(kind).all<{data:string}>(); return r.results.map(x=>JSON.parse(x.data)); }
  async get(id:string):Promise<RecordData|null> { const r=await this.db.prepare('SELECT data FROM records WHERE id=?').bind(id).first<{data:string}>(); return r?JSON.parse(r.data):null; }
  putStatement(kind:string,r:RecordData) { return this.db.prepare('INSERT INTO records(id,kind,data,updated) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data,updated=excluded.updated WHERE records.kind=excluded.kind').bind(r.id,kind,JSON.stringify(r),new Date().toISOString()); }
  async put(kind:string,r:RecordData) { await this.putStatement(kind,r).run(); return r; }
  async count(id:string) { return (await this.db.prepare('SELECT value FROM counters WHERE id=?').bind(id).first<{value:number}>())?.value||0; }
  async bump(id:string) { await this.db.prepare('INSERT INTO counters(id,value) VALUES(?,1) ON CONFLICT(id) DO UPDATE SET value=value+1').bind(id).run(); }
}

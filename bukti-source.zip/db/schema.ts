import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';
export const records = sqliteTable('records', { id: text('id').primaryKey(), kind: text('kind').notNull(), data: text('data').notNull(), updated: text('updated').notNull() }, t => [index('records_kind').on(t.kind)]);
export const sessions = sqliteTable('sessions', { hash: text('hash').primaryKey(), expires: integer('expires').notNull() });
export const counters = sqliteTable('counters', { id: text('id').primaryKey(), value: integer('value').notNull().default(0) });
export const locks = sqliteTable('locks', { id: text('id').primaryKey(), expires: integer('expires').notNull() });

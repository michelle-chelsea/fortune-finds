import Workspace from '../src/Workspace';
export default Workspace;

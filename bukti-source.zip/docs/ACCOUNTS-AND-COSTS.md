# Accounts and service costs

Checked against official sources on 5 October 2026 UTC (6 October in Perth). Your personal account acceptance, API access, tax treatment and available payout methods are **not verified**. Indonesian residence does not determine where your shoppers must live.

| Program | What the official material establishes | What you must confirm |
|---|---|---|
| Amazon Associates | Apply for the target Amazon marketplace. Creators API requires a valid Associates account for the same marketplace. Approved mobile apps have separate conditions. | Acceptance as an Indonesia-based applicant; available payout method for your actual address/bank; tax interview; website and any extra channel approval; separate API eligibility. |
| eBay Partner Network | Affiliate reports can be downloaded as CSV and accessed through reporting APIs. Restricted APIs/feeds require separate requests; normal EPN membership does not prove every integration is available. | Indonesia-based acceptance and payout choices in the portal. A definitive current Indonesia-specific eligibility list was not established by the checked official public pages. Contact EPN if the application does not answer it. |
| Etsy Affiliates | Current Etsy Help directs applications to Rakuten. The older Etsy policy still references Awin and says admission depends on residence and approval. Rakuten's payment-options page includes Indonesia in its international direct-deposit list. | Which network your account uses; Etsy acceptance; your network's payout options, currency and bank requirements. A supported payment country is not Etsy affiliate approval. |

Amazon documents checks, gift certificates and direct deposit, with international bank support limited by program and bank location. Do not assume Indonesian local-bank direct deposit is available. A gift certificate is not cash; check whether a bank will accept a foreign cheque before choosing it. [Amazon payment options](https://affiliate-program.amazon.com/help/node/topic/GGD9H76RMDDNEWAE), [international payments](https://affiliate-program.amazon.com/help/node/topic/G8VUMS6GTBCR9RGV), [Creators API registration](https://affiliate-program.amazon.com/creatorsapi/docs/en-us/onboarding/sign-up-as-an-amazon-associate), [program and mobile policies](https://affiliate-program.amazon.com/help/operating/policies).

EPN describes PayPal, direct deposit/electronic funds transfer, and a PayPal fee of 2% capped at USD 20 per month on its partnership page. Confirm your current account schedule, availability and terms; that public page contains migration-era material. PayPal's own payout documentation lists Indonesia as supporting sending, receiving and withdrawal, which alone does not prove EPN acceptance. [EPN partnership/payment information](https://partnernetwork.ebay.com/resources/our-partnership), [EPN reporting](https://partnernetwork.ebay.com/solutions/tracking-your-impact-through-online-reports), [API and feed access](https://partnernetwork.ebay.com/page/developer-questionnaire), [PayPal supported countries](https://developer.paypal.com/payouts/supported-features/).

Rakuten describes direct deposit, check and PayPal, depending on country and advertiser network. Its PayPal documentation requires a verified PayPal account and lists supported networks/currencies. Etsy approval remains separate. Etsy's older policy prohibits AI-generated images; Bukti uses original typographic layouts and does not synthesize product imagery. [Current Etsy application guide](https://help.etsy.com/hc/en-us/articles/360000335987-The-Etsy-Affiliates-Program-and-Creator-Collective), [Etsy affiliate policy](https://www.etsy.com/legal/affiliates/), [Rakuten payment options](https://pubhelp.rakutenadvertising.com/hc/en-us/articles/360059980311-Payment-Options), [Rakuten PayPal option](https://pubhelp.rakutenadvertising.com/hc/articles/360059980411).

## One setup checklist

1. Choose your shopper market, language and currency.
2. Prepare original useful recommendations and your public website, then apply separately to each program.
3. Complete the provider's identity, tax and payout steps. Store bank/tax details only in that provider's official portal.
4. Record website approval in Bukti and paste the full provider-issued links. Website approval does not approve mobile, social, email or paid advertising.
5. Use the product/evidence and report CSV imports until you have separately approved API access. No marketplace passwords or API keys are requested by the current manual connection forms.
6. If desired, configure a paid AI connection on the backend and a deliberate spending limit. No account, billing or paid advertising was activated during development.
7. Deploy and verify a scheduler as described in DEPLOYMENT.md before relying on unattended operation.

## Costs

| Service | Verified published cost or status |
|---|---|
| Local app, SQLite and template generation | No paid API is used. Your computer/internet costs are not recorded. |
| Sites hosting | **Unknown** for this workspace; no pricing or billing entitlement was verified. Do not substitute direct Cloudflare prices for Sites charges. |
| Standalone Cloudflare Workers | A Free plan is available; Paid has a minimum USD 5/month plus applicable usage. D1 has separate usage limits/pricing. No paid account was activated. [Workers pricing](https://developers.cloudflare.com/workers/platform/pricing/), [D1 pricing](https://developers.cloudflare.com/d1/platform/pricing/). |
| Expo EAS | Free plan lists up to 15 Android and 15 iOS builds; quotas and plan terms apply. No EAS account or build entitlement was verified. [Expo pricing](https://expo.dev/pricing). |
| OpenAI model generation | **Unknown until a model and current token prices are configured**. No paid calls made. [Official model pricing](https://developers.openai.com/api/docs/pricing). |
| Domain, app-store accounts, taxes, conversion/bank fees | **Unknown**; not purchased or estimated. |

The app's operating-cost ledger starts empty. Its estimated balance excludes unknown/unrecorded costs and keeps currencies separate.

# Importing your records

The app reads UTF-8 CSV files with a header row. Use the template download in the relevant screen. Files are limited to 1 MB, product imports to 100 rows and report imports to 500 rows. Invalid data rejects the import instead of partially accepting it. Spreadsheet formulas are stored as plain text; exports use JSON rather than executing spreadsheet content.

## Products

Columns:

`name,category,marketplace,productUrl,affiliateLink,targetCountry,language,currency,collection,suits,problem,benefits,limitations,rationale,rightsConfirmed,evidence,wikipediaTitle`

- Marketplace is `Amazon`, `eBay` or `Etsy`; language is `en` or `id`; currency is a three-letter uppercase code.
- `rightsConfirmed` is `true` only when you have checked the claims and can use the text.
- `evidence` is a JSON array stored in a quoted CSV cell. Escape double quotes by doubling them, as standard CSV requires. The product form is easier for beginners.
- Each evidence object has `url`, `observedAt`, `periodStart`, `periodEnd`, `country`, `signal`, `observation`, `limitations`, and `independent`.
- Dates use `YYYY-MM-DD`. Signals are `attention`, `purchase_intent`, `reported_sales`, or `review_activity`. Sales must be explicitly reported by the source; reviews and views do not prove purchases.
- Product imports create draft candidates. Reimporting a product CSV creates new candidates; review before importing it again. Commission imports use stricter duplicate protection.

## Commissions

Columns:

`marketplace,account,recordId,periodStart,periodEnd,currency,amount,status,attribution,productId`

- Use an account label, not bank details or a password.
- `recordId` must be a stable transaction/line identifier from the marketplace. For account totals, choose a stable ID covering the exact report period and type. Do not change that ID on a later status update.
- `amount` is commission, not order value; use a decimal point without currency symbols or thousands separators.
- `status` is `pending`, `approved`, `reversed`, or `paid`.
- `attribution` is `account` unless the source actually supplies a product attribution. `productId` is the saved Bukti ID and must match the marketplace for product-level rows.
- Rows are unique by marketplace + account + recordId. Reimporting a report does not add it twice. A new report version updates the existing row's status and value.
- Do not combine overlapping account totals with their individual transaction lines. The app cannot determine whether differently named records overlap economically.
- Provider-native report formats differ. Map the exported provider columns into this normalized template before import; there are no live provider adapters in this version.

Balance is current approved plus paid commissions minus recorded costs, separately for each currency. Pending and reversed commissions are excluded. It is an estimate, not cash in a bank or audited profit.

import { readFileSync, writeFileSync } from 'node:fs';
const p=JSON.parse(readFileSync('package.json','utf8'));p.type='module';p.scripts.setup='tsx scripts/setup.ts';p.scripts['build:native']='expo export --platform android --platform ios --output-dir native-dist';writeFileSync('package.json',JSON.stringify(p,null,2)+'\n');

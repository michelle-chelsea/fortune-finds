import {readFileSync} from 'node:fs';
const env=Object.fromEntries(readFileSync('.env.local','utf8').split(/\r?\n/).filter(x=>x.includes('=')).map(x=>[x.slice(0,x.indexOf('=')),x.slice(x.indexOf('=')+1)]));
process.stdout.write(JSON.stringify(Object.fromEntries(['OWNER_EMAIL','OWNER_PASSWORD_HASH','JOB_SECRET'].map(k=>[k,env[k]]))));

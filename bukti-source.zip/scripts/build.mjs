import { build } from 'esbuild';
import { mkdir, cp, readFile, writeFile } from 'node:fs/promises';
let html=await readFile('dist/client/index.html','utf8');html=html.replace(/<title>.*?<\/title>/s,'<title>Bukti · Affiliate workspace</title>');html=html.replace('</head>','<meta name="description" content="Research, approve and publish evidence-led affiliate recommendations."/><link rel="icon" href="/favicon.svg"/></head>');await writeFile('dist/client/index.html',html);
await mkdir('dist/server',{recursive:true});await build({entryPoints:['server/worker.ts'],outfile:'dist/server/index.js',bundle:true,format:'esm',platform:'browser',target:'es2022',minify:true});
await mkdir('dist/.openai',{recursive:true});await cp('.openai/hosting.json','dist/.openai/hosting.json');await cp('drizzle','dist/.openai/drizzle',{recursive:true});

import {readFileSync,writeFileSync} from 'node:fs';
function change(file,from,to){const s=readFileSync(file,'utf8');if(!s.includes(from))throw Error('Missing edit target '+file);writeFileSync(file,s.replace(from,to));}
change('src/Workspace.tsx',"import React,{useEffect,useState} from 'react';", "import React,{useEffect,useState} from 'react';\nimport {zipSync,strToU8} from 'fflate';");
change('src/Workspace.tsx',"await download('bukti-creatives.json',JSON.stringify(output,null,2),'application/json')", "const files:Record<string,Uint8Array>={'editable-copy.json':strToU8(JSON.stringify(output,null,2))};output.creatives.forEach((c:any,i:number)=>{files[String(i+1).padStart(2,'0')+'-creative.svg']=strToU8(c.svg);files[String(i+1).padStart(2,'0')+'-video-script.txt']=strToU8(c.videoScript)});await download('bukti-creatives.zip',zipSync(files),'application/zip')");
change('src/Workspace.tsx',"{tab==='settings'&&<Settings data={data} action={action}/>}","{tab==='settings'&&<Settings data={data} action={action} error={error}/>}");
change('src/Workspace.tsx','function Settings({data,action}:any)','function Settings({data,action,error}:any)');
change('src/Workspace.tsx','<H>{connection?.marketplace} · Manual setup</H>','<H>{connection?.marketplace} · Manual setup</H>{error&&<T style={{color:C.red}}>{error}</T>}');

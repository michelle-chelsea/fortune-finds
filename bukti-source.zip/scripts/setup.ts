import { writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { passwordHash } from '../server/auth.ts';
import { createInterface } from 'node:readline/promises';
if(existsSync('.env.local')){console.log('Setup already exists. Update .env.local to change server settings.');process.exit(0)}
mkdirSync('data',{recursive:true});
const auto=process.argv.includes('--development');const rl=auto?null:createInterface({input:process.stdin,output:process.stdout});const email=auto?'owner@bukti.local':await rl!.question('Owner email: ');const password=crypto.randomUUID()+'!Bukti';rl?.close();
const hash=await passwordHash(password);writeFileSync('.env.local',`OWNER_EMAIL=${email}\nOWNER_PASSWORD_HASH=${hash}\nSESSION_SECRET=${crypto.randomUUID()}\nJOB_SECRET=${crypto.randomUUID()}\nPUBLIC_ORIGIN=http://localhost:8787\n`);writeFileSync('data/owner-login.txt',`Bukti development login\nEmail: ${email}\nPassword: ${password}\n\nPrivate: do not commit or share this file. Change credentials before a public deployment.\n`);console.log('Owner login saved to data/owner-login.txt. This file is excluded from source control.');
